# Innomatics-Project-1
Analysis of AMCAT Data
